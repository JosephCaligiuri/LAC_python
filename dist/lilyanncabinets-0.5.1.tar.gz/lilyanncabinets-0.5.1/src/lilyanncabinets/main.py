import math

def equation(x):
    return 10