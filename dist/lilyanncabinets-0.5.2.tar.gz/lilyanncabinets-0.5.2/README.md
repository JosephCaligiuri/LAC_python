Version 0.5.2

patch notes: 

- 0.5.2: "Added equations for "limelight" functions"

- 0.5.1: "Started Unstable build 0.5"

reminder to py -m build
and py -m twine upload --repository pypi dist/*